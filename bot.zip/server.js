const express = require('express');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const app = express();
const PORT = 3002;


// Dados de login e senha (no exemplo, estão hardcoded, mas você pode colocar em um arquivo separado ou banco de dados)
const usuarios = {
    'admin': 'senha123', // Usuário: admin, Senha: senha123
};

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        args: ['--no-sandbox', '--disable-setuid-sandbox'] // Adicionando essas opções
    }
});

let qrCodeAtual = null;
let botConectado = false;

const delay = ms => new Promise(res => setTimeout(res, ms)); // Função que usamos para criar o delay entre uma ação e outra


// Caminhos dos arquivos JSON
const dataFile = path.join(__dirname, 'data.json');
const messagesFile = path.join(__dirname, 'messages.json');

// Função para garantir que o arquivo existe, caso contrário, criar com dados padrão
function garantirArquivoExistente(caminho, dadosPadrao) {
    if (!fs.existsSync(caminho)) {
        fs.writeFileSync(caminho, JSON.stringify(dadosPadrao, null, 2), 'utf8');
        console.log(`Arquivo criado: ${caminho}`);
    }
}

// Criar os arquivos necessários se não existirem
garantirArquivoExistente(dataFile, { clientes: [], mensagens_enviadas: [] });
garantirArquivoExistente(messagesFile, { faltando_2_dias: "", vencido: "" });

// Middleware para permitir JSON
app.use(express.json());
app.use(express.static('public'));

// Middleware para verificar se o usuário está autenticado
function verificarAutenticacao(req, res, next) {
    const token = req.headers['x-auth-token'];
    if (!token || !usuariosAutenticados.includes(token)) {
        return res.status(403).json({ message: 'Acesso não autorizado. Faça login para continuar.' });
    }
    next();
}

// Função para carregar os dados
function carregarDados() {
    return JSON.parse(fs.readFileSync(dataFile, 'utf8'));
}

// Função para salvar os dados
function salvarDados(dados) {
    fs.writeFileSync(dataFile, JSON.stringify(dados, null, 2), 'utf8');
}

// Função para carregar mensagens personalizadas
function carregarMensagens() {
    return JSON.parse(fs.readFileSync(messagesFile, 'utf8'));
}

let respostaEsperada = {};
let ACCESS_TOKEN = "APP_USR-6283229247289406-012213-257f44ca3f6d70311c6460089565c665-185540114";
let empresaNome = "THEFULLTV";
let planos = {
    "1m": "R$ 17,90",
    "6m": "R$ 88,00",
    "1a": "R$ 135,00"
};

// Rota para obter configurações da empresa
app.get('/configuracoes', (req, res) => {
    res.json({
        access_token: ACCESS_TOKEN,
        empresaNome: empresaNome,
        planos: planos
    });
});


// Rota de login
app.post('/login', (req, res) => {
    const { usuario, senha } = req.body;

    if (usuarios[usuario] && usuarios[usuario] === senha) {
        // Gerar token de sessão (pode ser mais seguro com JWT ou outra estratégia)
        const token = `${usuario}-${Date.now()}`;
        usuariosAutenticados.push(token);
        res.json({ message: 'Login bem-sucedido', token });
    } else {
        res.status(401).json({ message: 'Credenciais inválidas' });
    }
});


// Rota para atualizar o ACCESS_TOKEN, empresaNome e planos
app.put('/configuracoes', (req, res) => {
    let { access_token, empresaNome, planos: novosPlanos } = req.body;

    if (access_token) {
        ACCESS_TOKEN = access_token;
    }
    if (empresaNome) {
        empresaNome = empresaNome;
    }
    if (novosPlanos) {
        // Verifique se os planos estão no formato correto
        if (novosPlanos['1m'] && novosPlanos['6m'] && novosPlanos['1a']) {
            // Atualizar as propriedades de planos
            planos['1m'] = novosPlanos['1m'];
            planos['6m'] = novosPlanos['6m'];
            planos['1a'] = novosPlanos['1a'];
        } else {
            return res.status(400).json({ message: 'Os planos estão no formato inválido.' });
        }
    }

    res.json({ message: 'Configurações atualizadas com sucesso!' });
});


// Rota para pegar o status do bot
app.get('/status', (req, res) => {
    res.json({ conectado: botConectado, qr_code: qrCodeAtual });
});

// Rota para obter clientes
app.get('/clientes', (req, res) => {
    const data = carregarDados();
    res.json(data.clientes);
});

// Rota para adicionar cliente
app.post('/clientes', (req, res) => {
    const { nome, whatsapp, data_expiracao } = req.body;
    const data = carregarDados();

    data.clientes.push({ nome, whatsapp, data_expiracao });
    salvarDados(data);

    res.json({ message: 'Cliente adicionado!' });
});

// Rota para remover cliente
app.delete('/clientes/:whatsapp', (req, res) => {
    const { whatsapp } = req.params;
    const data = carregarDados();
    const mensagens = carregarMensagens();

    // Remover cliente do array de clientes
    data.clientes = data.clientes.filter(cliente => cliente.whatsapp !== whatsapp);

    // Remover as mensagens enviadas para o cliente
    data.mensagens_enviadas = data.mensagens_enviadas.filter(msg => msg.whatsapp !== whatsapp);

    salvarDados(data);

    res.json({ message: 'Cliente removido e mensagens excluídas!' });
});

// Conectar WhatsApp
client.on('qr', qr => {
    qrcode.toDataURL(qr, (err, url) => {
        qrCodeAtual = url;
    });
});

client.on('ready', () => {
    botConectado = true;
    qrCodeAtual = null;
    console.log('Bot conectado!');
    setInterval(verificarVencimentos, 5000); // Verifica os vencimentos a cada 10 segundos
});

client.on('disconnected', () => {
    botConectado = false;
    console.log('Bot desconectado. Gerando novo QR code...');
    qrCodeAtual = null; // Limpa o QR code antigo
    client.initialize(); // Re-inicializa o cliente para gerar um novo QR code
});

// Escutando todas as mensagens recebidas
client.on('message', (message) => {
    console.log(`Mensagem recebida de ${message.from}: ${message.body}`);
});

// Função para verificar vencimentos
function verificarVencimentos() {
    const data = carregarDados();
    const mensagens = carregarMensagens();
    const hoje = new Date();

    data.clientes.forEach(cliente => {
        const expira = new Date(cliente.data_expiracao);
        const diffDias = Math.ceil((expira - hoje) / (1000 * 60 * 60 * 24));

        let tipoMensagem = null;
        if (diffDias === 2) tipoMensagem = 'faltando_2_dias';
        if (diffDias <= 0) tipoMensagem = 'vencido';

        if (tipoMensagem && !data.mensagens_enviadas.some(msg => msg.whatsapp === cliente.whatsapp && msg.tipo === tipoMensagem)) {
            enviarMensagem(cliente, tipoMensagem, mensagens[tipoMensagem]);
            data.mensagens_enviadas.push({ whatsapp: cliente.whatsapp, tipo: tipoMensagem, data_envio: hoje.toISOString().split('T')[0] });
        }
    });

    salvarDados(data);
}

// Função para enviar mensagens via WhatsApp
async function enviarMensagem(cliente, tipo, mensagem) {
    if (!mensagem) return; // Evita envio se a mensagem estiver vazia

    const chatId = cliente.whatsapp + "@c.us";

    let saudacao = "Olá"; // Saudações que você pode personalizar conforme o horário

    if (tipo === 'vencido') {
        mensagem = `🤖 *Mensagem automática da ${empresaNome}* \n\n👋 *${saudacao}, ${cliente.nome}!* \n\n😩 *Sua Assinatura Expirou* ⏳💥\n\n📞 Entre em contato 📲 para renovar e evitar interrupções. ⚠️🔌\n\n💬 *Deseja renovar agora?*\n\n Digite uma das opções abaixo:\n\n1️⃣ - R$ ${planos['1m']}\n2️⃣ - 6 Meses R$ ${planos['6m']}\n3️⃣ - 1 Ano R$ ${planos['1a']}\n\n 📲 Digite o *Número* da opção desejada.'` ;
    } else if (tipo === 'faltando_2_dias') {
        mensagem = `🤖 *Mensagem automática da ${empresaNome}* \n\n👋 *${saudacao}, ${cliente.nome}!* \n\n, Sua Assinatura vence em 2 dias! 🚀\n\n💰 Renove agora para continuar assistindo sem interrupções.\n\n💬 *Deseja renovar agora?*\n\n Digite uma das opções abaixo:\n\n1️⃣ - R$ ${planos['1m']}\n2️⃣ - 6 Meses R$ ${planos['6m']}\n3️⃣ - 1 Ano R$ ${planos['1a']}\n\n 📲 Digite o *Número* da opção desejada.'` ;
    }

    try {
        await client.sendMessage(chatId, mensagem);
        console.log(`Mensagem enviada para ${cliente.nome} (${cliente.whatsapp})`);
    } catch (error) {
        console.error(`Erro ao enviar mensagem para ${cliente.whatsapp}:`, error);
    }
}





// Função para criar pagamento Pix
const criarPagamentoPix = async (numeroWhatsapp, valor) => {
    try {
        const url = "https://api.mercadopago.com/v1/payments";
        const headers = {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${ACCESS_TOKEN}`
        };

        // Dados da transação
        const data = {
            "transaction_amount": valor,
            "description": "Pix - Pagamento THEFULLNET",
            "payment_method_id": "pix",
            "payer": {
                "email": "aew.keito@gmail.com",
                "first_name": "Wellington",
                "last_name": "Silva",
                "identification": {
                    "type": "CPF",
                    "number": "19119119100"
                },
                "phone": {
                    "area_code": "11",
                    "number": numeroWhatsapp
                }
            }
        };

        // Realizando a requisição para o Mercado Pago
        const response = await axios.post(url, data, { headers });
        return response.data.point_of_interaction.transaction_data.qr_code;
    } catch (error) {
        console.error("Erro ao criar pagamento Pix:", error);
        throw new Error('Erro ao criar pagamento Pix');
    }
};

// Função para enviar mensagem com link do Pix
const enviarMensagemPix = async (numeroWhatsapp, valor) => {
    try {
        const qrCode = await criarPagamentoPix(numeroWhatsapp, valor);
        
        const mensagem = `✅ Gerando seu QR Code Pix, aguarde um momento...`;
        
        const mensagem1 = `Pix de R$ ${valor.toFixed(2)}\n\nChave Pix Copia e Cola: 👇`;
        await delay(2000);
        const mensagem2 = `${qrCode}`;
        
        // Envia a mensagem para o mesmo número do cliente
        await delay(2000);
        client.sendMessage(numeroWhatsapp, mensagem);
        await delay(2000);
        client.sendMessage(numeroWhatsapp, mensagem1);
        await delay(2000);
        client.sendMessage(numeroWhatsapp, mensagem2);
    } catch (error) {
        client.sendMessage(numeroWhatsapp, `Desculpe, houve um erro ao gerar o pagamento Pix. Por favor, tente novamente.`);
    }
};

// Função que lida com a mensagem recebida
client.on('message', async (message) => {
    const from = message.from;
    const body = message.body.trim();

    console.log(`Mensagem recebida de ${from}: ${body}`);

    if (body === '1' || body === '2' || body === '3') {
        let valor;

        // Definir o valor baseado na opção recebida
        if (body === '1') {
            valor = 17.90;
        } else if (body === '2') {
            valor = 88.90;
        } else if (body === '3') {
            valor = 123.90;
        }

        // Enviar o link do pagamento Pix para o mesmo número
        enviarMensagemPix(from, valor);
    } else {
        
    }
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://158.69.110.101:${PORT}`);
});

client.initialize();
