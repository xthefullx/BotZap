#!/bin/bash
cd ~/bot_whatsapp
node bot.js
