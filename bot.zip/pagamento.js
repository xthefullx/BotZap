const express = require('express');
const axios = require('axios');
const QRCode = require('qrcode');
const app = express();

const ACCESS_TOKEN = "APP_USR-6283229247289406-012213-257f44ca3f6d70311c6460089565c665-185540114";

// Função para criar pagamento Pix e gerar QR Code
const criarPagamentoPix = async (numeroWhatsapp, valor) => {
    try {
        // URL e cabeçalhos para a requisição
        const url = "https://api.mercadopago.com/v1/payments";
        const headers = {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${ACCESS_TOKEN}`
        };

        // Dados da transação
        const data = {
            "transaction_amount": valor,
            "description": "Pix - Pagamento THEFULLNET",
            "payment_method_id": "pix",
            "payer": {
                "email": "aew.keito@gmail.com",
                "first_name": "Wellington",
                "last_name": "Silva",
                "identification": {
                    "type": "CPF",
                    "number": "19119119100"
                },
                "phone": {
                    "area_code": "11",
                    "number": numeroWhatsapp
                }
            }
        };

        // Enviar requisição para criar pagamento
        const response = await axios.post(url, data, { headers });
        const pagamentoData = response.data;

        // Gerar o QR Code para o pagamento
        const qrCode = await QRCode.toDataURL(pagamentoData.point_of_interaction.transaction_data.qr_code);
        return {
            qrCodeBase64: qrCode,
            chavePix: pagamentoData.point_of_interaction.transaction_data.qr_code
        };
    } catch (error) {
        console.error("Erro ao criar pagamento Pix:", error);
        throw new Error('Erro ao gerar o pagamento Pix');
    }
};

// Rota para gerar o pagamento
app.post('/gerar-pagamento', async (req, res) => {
    const { whatsapp, valor } = req.body;

    if (!whatsapp || !valor) {
        return res.status(400).json({ success: false, message: "Número e valor são obrigatórios." });
    }

    try {
        const { qrCodeBase64, chavePix } = await criarPagamentoPix(whatsapp, valor);
        
        res.json({
            success: true,
            chave_pix: chavePix,
            qr_code_base64: qrCodeBase64
        });
    } catch (error) {
        res.status(500).json({ success: false, message: "Erro interno ao gerar pagamento." });
    }
});

app.listen(3001, () => {
    console.log("Servidor de pagamento rodando na porta 3001");
});
