const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Caminho do arquivo JSON
const dataFile = path.join(__dirname, 'data.json');

// Função para carregar os dados
function carregarDados() {
    if (!fs.existsSync(dataFile)) return { clientes: [], mensagens_enviadas: [] };
    return JSON.parse(fs.readFileSync(dataFile, 'utf8'));
}

// Função para salvar os dados
function salvarDados(dados) {
    fs.writeFileSync(dataFile, JSON.stringify(dados, null, 2), 'utf8');
}

// Criando o cliente WhatsApp
const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        args: ['--no-sandbox', '--disable-setuid-sandbox'] // Adicionando a flag
    }
});

// Exibir QR Code no terminal
client.on('qr', qr => {
    console.log('Escaneie o QR Code abaixo para conectar:');
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('Bot conectado ao WhatsApp!');
    setInterval(verificarVencimentos, 10000); // Verifica a cada 10 segundos
});

// Função para verificar vencimentos
function verificarVencimentos() {
    const dados = carregarDados();
    const hoje = new Date();

    dados.clientes.forEach(cliente => {
        const expira = new Date(cliente.data_expiracao);
        const diffDias = Math.ceil((expira - hoje) / (1000 * 60 * 60 * 24));

        let tipoMensagem = null;
        if (diffDias === 2) tipoMensagem = 'faltando_2_dias';
        if (diffDias <= 0) tipoMensagem = 'vencido';

        if (tipoMensagem && !dados.mensagens_enviadas.some(msg => msg.whatsapp === cliente.whatsapp && msg.tipo === tipoMensagem)) {
            enviarMensagem(cliente, tipoMensagem);
            dados.mensagens_enviadas.push({ whatsapp: cliente.whatsapp, tipo: tipoMensagem, data_envio: hoje.toISOString().split('T')[0] });
        }
    });

    salvarDados(dados);
}

// Função para enviar mensagens
async function enviarMensagem(cliente, tipo) {
    const saudacao = obterSaudacao();
    const chatId = cliente.whatsapp + "@c.us";

    let mensagem = "";
    if (tipo === 'vencido') {
        mensagem = `🤖 *Mensagem automática da THEFULLTV* \n\n👋 *${saudacao}, ${cliente.nome}!* ☀️🌟\n\n😩 *Sua Assinatura Expirou* ⏳💥\n\n📞 Entre em contato 📲 para renovar e evitar interrupções. ⚠️🔌\n\n💵 1 Mês R$ 17,90\n💵 6 Meses R$ 88,00\n💵 1 Ano R$ 135,00\n\n💬 *Deseja renovar agora? Responda com:* \n\n1️⃣ Para renovar 1 mês\n2️⃣ Para renovar 6 meses\n3️⃣ Para renovar 1 ano`;
    } else {
        mensagem = `⚠️ *Aviso de Expiração* \n\n📅 ${cliente.nome}, seu plano vence em 2 dias! 🚀\n\n💰 Renove agora para continuar assistindo sem interrupções.\n\n1️⃣ 1 Mês - R$ 17,90\n2️⃣ 6 Meses - R$ 88,00\n3️⃣ 1 Ano - R$ 135,00\n\n💬 Responda com o número da opção desejada.`;
    }

    await client.sendMessage(chatId, mensagem);
}

// Função para capturar resposta do usuário
client.on('message', async (message) => {
    const chatId = message.from;
    const mensagem = message.body.trim();

    if (["1", "2", "3"].includes(mensagem)) {
        const valores = { "1": 17.90, "2": 88.00, "3": 135.00 };
        const valor = valores[mensagem];

        await client.sendMessage(chatId, `✅ Gerando pagamento aguarde...`);

        try {
            const resposta = await axios.post('http://localhost:3001/gerar-pagamento', { whatsapp: chatId.replace("@c.us", ""), valor });
			
            // Convertendo base64 para imagem e enviando QR Code
            const qrCodeMedia = new MessageMedia('image/png', resposta.data.qr_code_base64);
            await client.sendMessage(chatId, qrCodeMedia, { caption: '✅ Pagamento gerado!'});
            await client.sendMessage(chatId,'💰 Valor: R$', `${valor}`);

            if (resposta.data.success) {
                await client.sendMessage(chatId, `*Chave Pix:* `);
                await client.sendMessage(chatId, `${resposta.data.chave_pix}`);
            } else {
                await client.sendMessage(chatId, `❌ Erro ao gerar pagamento. Tente novamente mais tarde.`);
            }
        } catch (error) {
            console.error("Erro ao gerar pagamento:", error);
            await client.sendMessage(chatId, `❌ Erro ao processar pagamento.`);
        }
    }
});

// Função para obter saudação baseada no horário
function obterSaudacao() {
    const hora = new Date().getHours();
    if (hora < 12) return 'Bom dia';
    if (hora < 18) return 'Boa tarde';
    return 'Boa noite';
}

client.initialize();
